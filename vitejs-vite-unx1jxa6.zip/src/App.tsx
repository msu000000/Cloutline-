import React, { useState } from "react";
import "./App.css";

const App = () => {
  const [topic, setTopic] = useState("");
    const [hooks, setHooks] = useState([]);
      const [loading, setLoading] = useState(false);

        const generateHooks = async () => {
            if (!topic) return;
                setLoading(true);
                    setHooks([]);

                        const response = await fetch("https://api.openai.com/v1/chat/completions", {
                              method: "POST",
                                    headers: {
                                            "Authorization": "Bearer sk-YOUR-API-KEY", // Replace with your key
                                                    "Content-Type": "application/json"
                                                          },
                                                                body: JSON.stringify({
                                                                        model: "gpt-3.5-turbo",
                                                                                messages: [{
                                                                                          role: "user",
                                                                                                    content: `Give me 5 viral hooks for: "${topic}"`
                                                                                                            }]
                                                                                                                  })
                                                                                                                      });

                                                                                                                          const data = await response.json();
                                                                                                                              const text = data.choices[0].message.content;
                                                                                                                                  const list = text.split("\n").filter(line => line.trim() !== "");
                                                                                                                                      setHooks(list);
                                                                                                                                          setLoading(false);
                                                                                                                                            };

                                                                                                                                              return (
                                                                                                                                                  <div className="app">
                                                                                                                                                        <h1>🎯 Cloutline AI</h1>
                                                                                                                                                              <p>Generate viral hooks for Reels & Shorts</p>

                                                                                                                                                                    <input
                                                                                                                                                                            type="text"
                                                                                                                                                                                    placeholder="Enter a topic (e.g. Gym)"
                                                                                                                                                                                            value={topic}
                                                                                                                                                                                                    onChange={(e) => setTopic(e.target.value)}
                                                                                                                                                                                                          />
                                                                                                                                                                                                                <button onClick={generateHooks} disabled={loading}>
                                                                                                                                                                                                                        {loading ? "Generating..." : "Generate Hooks"}
                                                                                                                                                                                                                              </button>

                                                                                                                                                                                                                                    <ul>
                                                                                                                                                                                                                                            {hooks.map((hook, i) => (
                                                                                                                                                                                                                                                      <li key={i}>{hook}</li>
                                                                                                                                                                                                                                                              ))}
                                                                                                                                                                                                                                                                    </ul>

                                                                                                                                                                                                                                                                          <a
                                                                                                                                                                                                                                                                                  href="https://msuvi.gumroad.com"
                                                                                                                                                                                                                                                                                          target="_blank"
                                                                                                                                                                                                                                                                                                  className="buy-button"
                                                                                                                                                                                                                                                                                                        >
                                                                                                                                                                                                                                                                                                                🔓 Unlock Pro Pack ($1)
                                                                                                                                                                                                                                                                                                                      </a>
                                                                                                                                                                                                                                                                                                                          </div>
                                                                                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                                                                                            };

                                                                                                                                                                                                                                                                                                                            export default App;